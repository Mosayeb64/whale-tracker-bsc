Whale Tracker for Hyperliquid (real-time)
================================================
This package contains a Telegram bot that connects to Hyperliquid WebSocket and sends real-time trade/position alerts to your Telegram chat.

Files:
- main.py          : main bot code (async)
- requirements.txt : python dependencies
- .env.example     : example env vars
- .env             : (optional) filled env for convenience (DO NOT SHARE)

Quick start on Replit (mobile):
1. Create a new Replit (choose Python).
2. Upload the ZIP contents or import from GitHub.
3. In Replit, open the Secrets (Environment variables) panel and set the variables from .env.example,
   or upload the .env file (less secure).
4. Replit installs requirements automatically or run: pip install -r requirements.txt
5. Click Run. Console shows logs; when trades surpass threshold, you'll get Telegram messages.

Important security note:
- The included .env file contains your token and chat id for convenience. Keep it private.
- Prefer using Replit Secrets instead of .env to avoid exposing the token.

If you want, I can also import this repository into your GitHub (or create a repo) so you can use Replit's GitHub import.
