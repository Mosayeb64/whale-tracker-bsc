import os
import asyncio
import json
import time
from dotenv import load_dotenv
import aiohttp
import websockets
from telegram import Bot
from telegram.ext import ApplicationBuilder, CommandHandler

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
ALERT_CHAT_ID = int(os.getenv("ALERT_CHAT_ID", "0"))
HYPER_WS = os.getenv("HYPER_WS", "wss://api.hyperliquid.xyz/ws")
HYPER_INFO = os.getenv("HYPER_INFO", "https://api.hyperliquid.xyz/info")
HYPER_API_KEY = os.getenv("HYPER_API_KEY", "")  # optional
THRESHOLD = float(os.getenv("THRESHOLD_USD", "300000"))
COINS = [c.strip().upper() for c in os.getenv("HYPER_COINS", "BTC,ETH,SOL,BNB,AVAX").split(",") if c.strip()]

bot = Bot(TELEGRAM_TOKEN)

async def start_command(update, context):
    global ALERT_CHAT_ID
    ALERT_CHAT_ID = update.effective_chat.id
    await update.message.reply_text("Whale monitor registered in this chat. You will receive alerts here.")

async def send_telegram(text):
    if ALERT_CHAT_ID == 0:
        print("No chat id registered; send /start in the target chat.")
        return
    try:
        await bot.send_message(chat_id=ALERT_CHAT_ID, text=text, parse_mode="HTML", disable_web_page_preview=True)
    except Exception as e:
        print("Telegram send error:", e)

async def hyper_info_request(session, payload):
    headers = {"Content-Type": "application/json"}
    if HYPER_API_KEY:
        headers["Authorization"] = f"Bearer {HYPER_API_KEY}"
    try:
        async with session.post(HYPER_INFO, json=payload, headers=headers, timeout=20) as r:
            return await r.json()
    except Exception as e:
        print("hyper_info_request error:", e)
        return None

_seen_alerts = set()
def make_alert_id(kind, unique):
    k = f"{kind}:{unique}"
    if k in _seen_alerts:
        return None
    _seen_alerts.add(k)
    if len(_seen_alerts) > 10000:
        _seen_alerts.clear()
    return k

async def handle_trade(session, trade):
    try:
        coin = trade.get("coin") or trade.get("symbol")
        side = trade.get("side") or trade.get("dir") or ""
        px = float(trade.get("px", 0) or 0)
        sz = float(trade.get("sz", 0) or 0)
        ts = int(trade.get("time", int(time.time()*1000)))
        txhash = trade.get("hash") or trade.get("tid") or ""
        users = trade.get("users", [])

        notional = px * sz
        if notional < THRESHOLD:
            return

        leverage = "N/A"
        stop_loss = "N/A"
        entry_price = f"{px:,.6f}"

        if users and isinstance(users, list) and users[0]:
            user_addr = users[0]
            payload = {"type": "clearinghouseState", "user": user_addr}
            info = await hyper_info_request(session, payload)
            try:
                if info and isinstance(info, dict):
                    pos = info.get("assetPositions") or info.get("positions") or info.get("perpPositions")
                    if pos and isinstance(pos, list) and len(pos) > 0:
                        for p in pos:
                            if (p.get("coin") and p.get("coin").upper() == coin) or (p.get("asset") and p.get("asset").upper() == coin):
                                leverage = p.get("leverage") or p.get("lev") or "N/A"
                                stop_loss = p.get("liquidationPrice") or p.get("liq_px") or "N/A"
                                entry_price = p.get("entryPrice") or entry_price
                                break
            except Exception as e:
                print("parsing info error:", e)

        side_str = trade.get("dir") or ("Long" if str(side).lower() in ("b","buy","buyer") else "Short" if str(side).lower() in ("s","sell","seller") else str(side))
        time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts/1000))
        alert_id = make_alert_id("trade", f"{txhash}:{trade.get('tid')}")
        if not alert_id:
            return

        text = (
            f"📊 <b>{coin}</b>\n"
            f"🟢 <b>Side:</b> {side_str}\n"
            f"💵 <b>Entry:</b> {entry_price}\n"
            f"🛡 <b>Stop Loss:</b> {stop_loss}\n"
            f"⚡ <b>Leverage:</b> {leverage}\n"
            f"📦 <b>Size:</b> {sz:,.4f}\n"
            f"💰 <b>Notional (USD):</b> ${notional:,.2f}\n"
            f"🕒 <b>Time:</b> {time_str} UTC\n"
            f"🔗 <a href=\"https://app.hyperliquid.xyz/tx/{txhash}\">Tx / Details</a>"
        )
        await send_telegram(text)
    except Exception as e:
        print("handle_trade error:", e)

async def hyper_ws_loop():
    async with aiohttp.ClientSession() as session:
        async with websockets.connect(HYPER_WS, ping_interval=30) as ws:
            for coin in COINS:
                sub = {"method": "subscribe", "subscription": {"type": "trades", "coin": coin}}
                await ws.send(json.dumps(sub))
                try:
                    ack = await ws.recv()
                    print("sub ack:", ack)
                except Exception:
                    pass

            while True:
                raw = await ws.recv()
                try:
                    msg = json.loads(raw)
                except Exception:
                    continue
                channel = msg.get("channel")
                data = msg.get("data")
                if channel == "trades" and data:
                    for t in data:
                        asyncio.create_task(handle_trade(session, t))

async def main():
    application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    application.add_handler(CommandHandler("start", start_command))
    loop = asyncio.get_event_loop()
    loop.create_task(hyper_ws_loop())
    await application.run_polling()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("shutting down")
