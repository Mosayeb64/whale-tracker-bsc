# Whale Bot (Starter)

This minimal Telegram bot just sends a test message on start.
Use it to verify your bot token & chat id.

## Files
- `main.py` - Bot code (Python)
- `requirements.txt` - Python dependencies
- `.env` - **PRIVATE** values (do not upload to public repos)
- `.env.example` - Template for env values

## Run (local or VPS)
1. `pip install -r requirements.txt`
2. Create `.env` file:
```
TELEGRAM_TOKEN=YOUR_TOKEN
CHAT_ID=YOUR_CHAT_ID
```
3. `python main.py`

## Replit
- Put values in **Secrets** (TELEGRAM_TOKEN, CHAT_ID)
- Click **Run**
