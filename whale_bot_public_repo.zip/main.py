import os
from telegram import Bot
from dotenv import load_dotenv

# Load env vars
load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

if not TOKEN or not CHAT_ID:
    raise RuntimeError("Missing TELEGRAM_TOKEN or CHAT_ID. Put them in .env or Replit Secrets.")

bot = Bot(token=TOKEN)

def main():
    bot.send_message(chat_id=CHAT_ID, text="✅ Bot started successfully.")

if __name__ == "__main__":
    main()
