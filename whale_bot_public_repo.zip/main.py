import os
import telebot

TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "✅ Whale Tracker Bot is running!")

# Sample alert sender
def send_alert(msg):
    bot.send_message(CHAT_ID, f"🐋 Whale Alert: {msg}")

if __name__ == "__main__":
    print("Bot started...")
    bot.infinity_polling()
